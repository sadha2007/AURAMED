import json
import logging
import markdown
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates

from app.dependencies import require_user
from app.services import intake as intake_service
from app.services.ai_doctor import (
    get_ai_response,
    build_prescription_json,
    format_medical_history,
)

router = APIRouter(prefix="/patient-dashboard", tags=["doctor-dashboard"])
templates = Jinja2Templates(directory="app/templates")
logger = logging.getLogger(__name__)


def markdown_to_html(text: str) -> str:
    if not text:
        return ""
    return markdown.markdown(text, extensions=["extra", "nl2br"])


# Register the filter directly into the dictionary
templates.env.filters["markdown_to_html"] = markdown_to_html


@router.get("", response_class=HTMLResponse)
async def dashboard_list(
    request: Request,
    priority: str = "",
    q: str = "",
    user=Depends(require_user),
) -> HTMLResponse:
    """Doctor-facing intake list: all incoming kiosk intakes, sortable by priority and searchable."""
    intakes = intake_service.list_intakes(priority=priority, search=q)

    # Count high-priority for badge across all intakes
    all_intakes = intake_service.list_intakes()
    high_priority_count = sum(1 for i in all_intakes if i.get("triage_priority") == "high")

    return templates.TemplateResponse(
        request,
        "patient_dashboard.html",
        {
            "user": user,
            "page_title": "Patient Intake Dashboard",
            "page_description": "Review incoming kiosk patient registrations and run AI consultations",
            "intakes": intakes,
            "high_priority_count": high_priority_count,
            "priority_filter": priority,
            "q": q,
            "step": "list",
        },
    )


@router.get("/intake/{intake_id}", response_class=HTMLResponse)
async def intake_detail(
    request: Request,
    intake_id: str,
    user=Depends(require_user),
) -> HTMLResponse:
    """Single intake: patient info, uploaded documents, AI doctor chat interface, prescription JSON."""
    intake = intake_service.get_intake(intake_id)
    if not intake:
        raise HTTPException(status_code=404, detail="Intake not found")

    # Fetch medical history for AI context
    mobile_number = intake.get("mobile_number")
    abha_id = intake.get("abha_id")
    past_intakes = intake_service.get_past_intakes_for_patient(mobile_number, abha_id)

    # Pre-format medical history for the AI
    medical_context = format_medical_history(past_intakes)

    # Load existing chat history if available
    chat_history = intake.get("ai_chat_history", []) or []

    # Load existing prescription JSON if available
    prescription_json = intake.get("prescription_json")
    prescription_json_str = (
        json.dumps(prescription_json, indent=2) if prescription_json else ""
    )

    return templates.TemplateResponse(
        request,
        "patient_dashboard.html",
        {
            "user": user,
            "page_title": f"Patient Intake: {intake.get('full_name', 'Unknown')}",
            "page_description": "Review patient details, chat with AI doctor, generate prescription",
            "intake": intake,
            "chat_history": chat_history,
            "prescription_json": prescription_json_str,
            "medical_context": medical_context,
            "step": "detail",
        },
    )


@router.post("/ai-chat")
async def ai_doctor_chat(
    request: Request,
    intake_id: str = Form(...),
    user_message: str = Form(...),
    user=Depends(require_user),
) -> JSONResponse:
    """
    Sends a message to the AI doctor and gets a response.

    Expects: { intake_id, user_message }
    Returns: { ai_response, is_emergency, updated_chat_history, chat_id }
    """
    intake = intake_service.get_intake(intake_id)
    if not intake:
        return JSONResponse({"error": "Intake not found"}, status_code=404)

    # Load existing chat history
    chat_history = intake.get("ai_chat_history", []) or []

    # Add user message to history
    chat_history.append({"role": "user", "text": user_message})

    # Get medical context for the AI
    mobile_number = intake.get("mobile_number")
    abha_id = intake.get("abha_id")
    past_intakes = intake_service.get_past_intakes_for_patient(mobile_number, abha_id)
    medical_context = format_medical_history(past_intakes)

    # Get AI response
    try:
        ai_response, is_emergency = await get_ai_response(
            user_message, chat_history, medical_context
        )
    except Exception as exc:
        logger.exception("AI doctor error: %s", exc)
        return JSONResponse(
            {
                "error": "Failed to get AI response. Please try again or contact support.",
                "is_emergency": False,
            },
            status_code=500,
        )

    # Add AI response to history
    chat_history.append({"role": "assistant", "text": ai_response})

    # Save updated chat history back to the intake
    intake_service.save_ai_consultation(intake_id, chat_history, None)

    # If emergency was detected in this exchange, update the triage priority
    if is_emergency and intake.get("triage_priority") != "high":
        try:
            db.table("patient_intakes").update({"triage_priority": "high"}).eq(
                "id", intake_id
            ).execute()
            logger.warning(
                f"Emergency detected in AI consultation for intake {intake_id}, escalated to HIGH priority"
            )
        except Exception as exc:
            logger.exception("Failed to escalate priority: %s", exc)

    return JSONResponse(
        {
            "ai_response": ai_response,
            "is_emergency": is_emergency,
            "updated_chat_history": chat_history,
            "chat_id": intake_id,
        }
    )


@router.post("/generate-prescription/{intake_id}")
async def generate_prescription(
    request: Request,
    intake_id: str,
    user=Depends(require_user),
) -> JSONResponse:
    """
    Generates a structured prescription JSON from the AI consultation.

    This is what doctors download and use to create the formal prescription.
    """
    intake = intake_service.get_intake(intake_id)
    if not intake:
        return JSONResponse({"error": "Intake not found"}, status_code=404)

    chat_history = intake.get("ai_chat_history", []) or []
    if not chat_history:
        return JSONResponse(
            {"error": "No AI consultation yet. Please chat with the AI doctor first."},
            status_code=400,
        )

    # Build the prescription JSON
    prescription_json = build_prescription_json(
        patient_name=intake.get("full_name", "Unknown"),
        symptoms=intake.get("symptom_pills", []),
        conversation=chat_history,
        is_emergency=intake.get("triage_priority") == "high",
        triage_priority=intake.get("triage_priority", "routine"),
        red_flags=intake.get("red_flags", []),
    )

    # Save it to the intake
    try:
        intake_service.save_ai_consultation(intake_id, chat_history, prescription_json)
    except Exception as exc:
        logger.exception("Failed to save prescription: %s", exc)
        return JSONResponse({"error": "Failed to save prescription"}, status_code=500)

    # Return as JSON for download
    return JSONResponse(
        {
            "success": True,
            "prescription": prescription_json,
            "filename": f"{intake.get('full_name', 'patient').replace(' ', '_')}_prescription.json",
        }
    )


# Import db here to avoid circular imports, but only when actually used
from app.supabase_client import db
