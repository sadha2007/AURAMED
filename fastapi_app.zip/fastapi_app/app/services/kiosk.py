import json
import os
import uuid
from datetime import datetime, timezone
from typing import List, Dict, Any, Tuple
from app.supabase_client import db

RED_FLAG_KEYWORDS = [
    "chest pain",
    "breathless",
    "shortness of breath",
    "severe bleeding",
    "unconscious",
    "stroke",
    "numbness",
    "heart attack",
    "fainting",
    "coughing blood",
    "anaphylaxis",
    "stabbing pain",
]


def analyze_symptoms_with_gemini(
    symptoms: List[str], transcript: str, document_texts: List[str] = None
) -> Dict[str, Any]:
    """
    Analyzes patient input using Google Gemini API to produce medical summary,
    triage assessment, and intelligent follow-up questions.
    """
    gemini_key = os.getenv("GEMINI_API_KEY")
    combined_notes = (
        f"Selected Symptoms: {', '.join(symptoms)}\nVoice/Text Transcript: {transcript}"
    )
    if document_texts:
        combined_notes += f"\nUploaded Records Text: {' '.join(document_texts)}"

    # If key is available, attempt call to Google Gemini via API client or REST fallback
    if gemini_key:
        try:
            import google.generativeai as genai

            genai.configure(api_key=gemini_key)
            model = genai.GenerativeModel("gemini-1.5-flash")

            prompt = f"""
            You are an AI clinical triage assistant. Analyze this patient intake data:
            {combined_notes}

            Respond strictly in valid JSON format with the following keys:
            - "summary": A concise clinical summary of the reported symptoms and history.
            - "is_emergency": true/false based on acute symptoms.
            - "triage_reason": Brief explanation of priority level.
            - "followup_questions": An array of 2-3 clinical follow-up questions for the doctor or kiosk.
            """

            response = model.generate_content(prompt)
            clean_text = response.text.replace("```json", "").replace("```", "").strip()
            return json.loads(clean_text)
        except Exception as e:
            print(f"Gemini API call warning/fallback: {e}")

    is_emergency = any(kw in combined_notes.lower() for kw in RED_FLAG_KEYWORDS)
    return {
        "summary": f"Patient reports symptoms: {', '.join(symptoms)}. Notes: {transcript[:200]}",
        "is_emergency": is_emergency,
        "triage_reason": (
            "High priority: potential red flag symptom detected."
            if is_emergency
            else "Routine consultation intake."
        ),
        "followup_questions": [
            "How long have you experienced these symptoms?",
            "Are you currently taking any prescription medications?",
            "Do you have any known allergies?",
        ],
    }


def build_kiosk_fhir_bundle(
    patient_id: str,
    abha_id: str,
    symptoms: List[str],
    transcript: str,
    ai_analysis: Dict[str, Any],
) -> Dict[str, Any]:
    """Builds a compliant HL7 FHIR R4 collection bundle for ABHA interoperability."""
    now_iso = datetime.now(timezone.utc).isoformat()
    bundle_id = str(uuid.uuid4())

    entries = [
        {
            "fullUrl": f"urn:uuid:{patient_id}",
            "resource": {
                "resourceType": "Patient",
                "id": patient_id,
                "identifier": [
                    {"system": "https://healthid.ndhm.gov.in", "value": abha_id}
                ],
                "active": True,
            },
        },
        {
            "fullUrl": f"urn:uuid:{uuid.uuid4()}",
            "resource": {
                "resourceType": "Observation",
                "status": "final",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "http://terminology.hl7.org/CodeSystem/observation-category",
                                "code": "survey",
                            }
                        ]
                    }
                ],
                "code": {"text": "Voice Intake Notes & AI Summary"},
                "subject": {"reference": f"Patient/{patient_id}"},
                "effectiveDateTime": now_iso,
                "valueString": f"Transcript: {transcript} | AI Summary: {ai_analysis.get('summary', '')}",
            },
        },
    ]

    for symptom in symptoms:
        entries.append(
            {
                "fullUrl": f"urn:uuid:{uuid.uuid4()}",
                "resource": {
                    "resourceType": "Condition",
                    "clinicalStatus": {
                        "coding": [
                            {
                                "system": "http://terminology.hl7.org/CodeSystem/condition-clinical",
                                "code": "active",
                            }
                        ]
                    },
                    "verificationStatus": {
                        "coding": [
                            {
                                "system": "http://terminology.hl7.org/CodeSystem/condition-ver-status",
                                "code": "unconfirmed",
                            }
                        ]
                    },
                    "code": {"text": symptom},
                    "subject": {"reference": f"Patient/{patient_id}"},
                    "recordedDate": now_iso,
                },
            }
        )

    return {
        "resourceType": "Bundle",
        "id": bundle_id,
        "type": "collection",
        "timestamp": now_iso,
        "entry": entries,
    }


def save_kiosk_intake(
    user_id: str | None,
    abha_id: str,
    symptoms: List[str],
    transcript: str,
    documents: List[str],
    consent_granted: bool,
) -> Dict[str, Any]:
    """Saves intake data, syncs or creates patient record, and triggers FHIR + AI generation."""

    # Check if patient exists with ABHA ID or create one
    existing_patient = (
        db.table("patients").select("*").eq("phone", abha_id).execute().data
    )

    if existing_patient:
        patient = existing_patient[0]
        patient_id = patient["id"]
    else:
        new_id = str(uuid.uuid4())
        new_patient = {
            "id": new_id,
            "created_by": user_id,
            "ayush_id": f"ABHA-{abha_id[-6:] if len(abha_id)>=6 else '1001'}",
            "full_name": f"Patient {abha_id[-4:]}",
            "phone": abha_id,
            "chief_complaints": ", ".join(symptoms),
            "medical_history": transcript[:250],
            "last_visit": datetime.now(timezone.utc).isoformat(),
        }
        res = db.table("patients").insert(new_patient).execute()
        patient = res.data[0]
        patient_id = patient["id"]

    # Analyze with Gemini AI
    ai_analysis = analyze_symptoms_with_gemini(symptoms, transcript)

    # Generate FHIR bundle
    fhir_bundle = build_kiosk_fhir_bundle(
        patient_id, abha_id, symptoms, transcript, ai_analysis
    )

    # Insert into patient_intakes
    intake_record = {
        "id": str(uuid.uuid4()),
        "patient_id": patient_id,
        "user_id": user_id,
        "abha_id": abha_id,
        "symptoms": symptoms,
        "voice_transcript": transcript,
        "extracted_medical_summary": ai_analysis.get("summary"),
        "ai_followup_questions": ai_analysis.get("followup_questions", []),
        "documents": documents,
        "is_emergency": ai_analysis.get("is_emergency", False),
        "triage_reason": ai_analysis.get("triage_reason"),
        "fhir_bundle": fhir_bundle,
        "consent_granted": consent_granted,
        "status": "pending_consultation",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }

    intake_res = db.table("patient_intakes").insert(intake_record).execute()
    return intake_res.data[0]


def get_patient_intakes_for_doctor() -> List[Dict[str, Any]]:
    """Fetches all recent patient kiosk intakes for the doctor dashboard."""
    res = (
        db.table("patient_intakes")
        .select("*, patients(full_name, ayush_id, phone)")
        .order("created_at", desc=True)
        .execute()
    )
    return res.data
