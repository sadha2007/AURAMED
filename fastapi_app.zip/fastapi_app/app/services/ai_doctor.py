import os
import logging
from datetime import datetime, timezone
from typing import Any

import google.generativeai as genai

logger = logging.getLogger(__name__)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    raise RuntimeError("GEMINI_API_KEY environment variable is required but not set")

genai.configure(api_key=GEMINI_API_KEY)

EMERGENCY_KEYWORDS = [
    "chest pain",
    "pressure in chest",
    "difficulty breathing",
    "shortness of breath",
    "can't breathe",
    "cannot breathe",
    "severe bleeding",
    "heavy bleeding",
    "unconscious",
    "passed out",
    "loss of consciousness",
    "seizure",
    "stroke",
    "face drooping",
    "slurred speech",
    "weakness on one side",
    "suicidal",
    "overdose",
    "severe pain",
    "acute pain",
]

SYSTEM_PROMPT = """You are Dr. Ayurveda, an expert AI medical intake assistant specializing in Ayurvedic and modern medicine at a hospital clinic.

YOUR ROLE:
1. Conduct empathetic, thorough patient intake consultations
2. Understand Ayurvedic concepts (Vata, Pitta, Kapha, Agni, Ojas) alongside modern medicine
3. Ask targeted follow-up questions to understand symptoms deeply
4. Build a patient narrative that can be converted to a structured prescription
5. Detect emergency situations and escalate appropriately

CRITICAL GUIDELINES:
1. NEVER diagnose diseases. Use phrases like "may suggest," "could indicate," "warrants investigation"
2. NEVER prescribe specific medications. Instead, describe therapeutic approaches and recommend consulting their doctor
3. NEVER claim certainty. Express findings as "patterns consistent with..." or "suggests..."
4. Ask concise, focused questions (2-3 per response max)
5. For Ayurvedic consultation: ask about digestion, energy levels, sleep, tongue coating, pulse rhythm if relevant
6. Reference patient's previous medical history when available
7. Keep responses warm, professional, under 300 words
8. If any emergency keywords appear in patient messages, IMMEDIATELY advise seeking emergency care

PRESCRIPTION FORMATTING (when appropriate to suggest elements):
Structure any therapeutic recommendations as:
- Dosha Imbalance: [what imbalance you observe based on symptoms]
- Therapeutic Approach: [general category, e.g., "Cooling Pitta Therapy"]
- Suggested Consultations: [which specialists, e.g., "Ayurveda physician, Allopathic gastroenterologist"]
- Dietary Guidance: [general principles, not specific meal plans]
- Lifestyle Adjustments: [sleep, activity, stress management recommendations]

Always end consultations with: "Please discuss these observations with your doctor for a formal evaluation and prescription."
FORMATTING INSTRUCTIONS:
- Use Markdown bolding (**text**) for emphasis on key terms.
- Use bullet points (*) for lists of symptoms, dietary guidance, or lifestyle tips.
- Keep sections clearly separated with blank lines.

Keep the output under 1000 characters
"""


def detect_emergency(text: str) -> bool:
    """Checks if the text contains any emergency keywords."""
    text_lower = text.lower()
    return any(keyword in text_lower for keyword in EMERGENCY_KEYWORDS)


def format_medical_history(past_intakes: list[dict[str, Any]]) -> str:
    """Formats past intakes into a readable medical context for the AI."""
    if not past_intakes:
        return "No previous medical history available."

    history_lines = ["PATIENT MEDICAL HISTORY:"]

    # Show last 3 visits
    for intake in past_intakes[-3:]:
        date_str = intake.get("created_at", "Unknown")
        if isinstance(date_str, str):
            date_str = date_str.split("T")[0]  # Extract just the date part

        history_lines.append(f"\n---")
        history_lines.append(f"Date: {date_str}")

        # Symptoms
        symptoms = intake.get("symptom_pills", [])
        if symptoms:
            if isinstance(symptoms, list):
                history_lines.append(f"Symptoms: {', '.join(symptoms)}")

        # Notes/narrative
        notes = intake.get("symptom_notes", "")
        if notes:
            history_lines.append(f"Description: {notes[:200]}...")

        # Triage result
        priority = intake.get("triage_priority", "routine")
        if priority == "high":
            flags = intake.get("red_flags", [])
            history_lines.append(f"⚠️ HIGH PRIORITY: {', '.join(flags)}")

    return "\n".join(history_lines)


async def get_ai_response(
    user_message: str,
    chat_history: list[dict[str, str]],
    medical_context: str = "",
) -> tuple[str, bool]:
    """
    Sends a message to Gemini and gets a response.

    Returns:
        (response_text, is_emergency) — the AI's response and whether an
        emergency was detected in the conversation.
    """
    is_emergency = detect_emergency(user_message)

    # Build conversation history for Gemini (last 10 exchanges)
    messages = []
    for item in chat_history[-20:]:  # Include more context, but not too much
        messages.append(
            {
                "role": item.get("role", "user"),
                "parts": [{"text": item.get("text", "")}],
            }
        )

    # Add the current user message
    messages.append({"role": "user", "parts": [{"text": user_message}]})

    try:
        model = genai.GenerativeModel(
            model_name="gemini-3.6-flash",
            system_instruction=SYSTEM_PROMPT + "\n\n" + medical_context,
        )

        response = model.generate_content(
            messages,
            generation_config=genai.types.GenerationConfig(
                temperature=0.7,
                max_output_tokens=1200,
                top_p=0.95,
            ),
        )

        if response and response.text:
            ai_reply = response.text.strip()
            is_emergency = is_emergency or detect_emergency(ai_reply)
            return ai_reply, is_emergency

    except Exception as exc:
        logger.exception("Gemini API error: %s", exc)

    return (
        "I'm having trouble processing your message right now. Please try again or contact your doctor directly.",
        is_emergency,
    )


def build_prescription_json(
    patient_name: str,
    symptoms: list[str],
    conversation: list[dict[str, str]],
    is_emergency: bool,
    triage_priority: str = "routine",
    red_flags: list[str] = None,
) -> dict[str, Any]:
    """
    Builds a structured JSON prescription from the AI consultation.

    This is what doctors see when reviewing a patient intake.
    """
    red_flags = red_flags or []

    # Extract key points from conversation
    last_ai_response = ""
    for item in reversed(conversation):
        if item.get("role") == "assistant":
            last_ai_response = item.get("text", "")
            break

    full_transcript = "\n".join(
        f"[{item.get('role', 'unknown').upper()}]: {item.get('text', '')}"
        for item in conversation
    )

    return {
        "metadata": {
            "patient_name": patient_name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "consultation_type": "AI Intake",
            "status": "pending_doctor_review",
            "is_emergency": is_emergency,
            "triage_priority": triage_priority,
            "red_flags": red_flags,
        },
        "chief_complaint": {
            "symptoms": symptoms,
            "onset": "Patient-reported during intake",
        },
        "ai_assessment": {
            "narrative": (
                last_ai_response[:500]
                if last_ai_response
                else "No assessment available"
            ),
            "key_observations": _extract_observations(last_ai_response),
        },
        "recommended_actions": {
            "immediate": (
                "EMERGENCY: Seek immediate medical care"
                if is_emergency
                else "Schedule consultation with treating physician"
            ),
            "follow_up": "Doctor to review full consultation transcript and determine next steps",
            "specialist_consideration": (
                "Emergency medicine"
                if is_emergency
                else "Internal medicine / Ayurveda physician"
            ),
        },
        "full_consultation_transcript": full_transcript,
        "documents_attached": [],
    }


def _extract_observations(ai_response: str) -> list[str]:
    """Extracts bullet-point observations from the AI response."""
    if not ai_response:
        return []

    observations = []
    lines = ai_response.split("\n")

    for line in lines:
        line = line.strip()
        if line and any(
            line.startswith(prefix) for prefix in ["- ", "• ", "* ", "1.", "2."]
        ):
            observations.append(line.lstrip("- •* 0123456789.").strip())

    return observations[:5]  # Max 5 key observations
