# AyushFHIR - AI-Powered Ayurvedic EHR & Clinical Intelligence Platform

An enterprise-ready **FastAPI** healthcare application that merges traditional **Ayurvedic clinical workflows** with modern healthcare interoperability standards (**HL7 FHIR R4**) and **Google Gemini Generative AI**.

---

## 🌟 Key Features

1. **🤖 Gemini AI Doctor Intake & Consultation (`/patient-dashboard`)**
   - Interactive clinical reasoning powered by **Google Gemini AI** (`google-generativeai`).
   - Analyzes Dosha imbalances (*Vata*, *Pitta*, *Kapha*), Agni, digestion, and systemic patterns.
   - Built-in emergency keyword triage and guardrails (e.g., chest pain, shortness of breath).
   - Generates structured, non-prescriptive therapeutic guidance and lifestyle recommendations.

2. **📋 EHR Progress Notes & FHIR R4 Bundle Generation (`/ehr`)**
   - Full patient intake: Demographics, Prakriti assessment, vital signs, and SOAP progress notes.
   - Converts clinical encounters into compliant **FHIR R4 JSON Bundles** (`Encounter`, `Condition`, `Observation`, `MedicationRequest`).
   - Automatically cross-references clinical findings with AYUSH national terminologies.

3. **🔍 NAMASTE Code Search Engine (`/namaste`)**
   - Instant search and auto-suggest across official **NAMASTE** (National AYUSH Morbidity and Standardized Terminologies Electronic) codes.
   - Correlates Ayurvedic diagnoses with ICD-11 / SNOMED CT terminology.

4. **🥗 Prakriti Diet Engine (`/diet`)**
   - Personalized diet builder calculating compatibility against patient dosha and health conditions.
   - Evaluates Ayurvedic food attributes (*Rasa*, *Virya*, *Vipaka*) and food-disease contraindications.

5. **👥 Patient History & Records (`/history`)**
   - Comprehensive dashboard of all registered patients, vitals summaries, previous encounters, and clinical history.

6. **⚡ Complete Offline-First Design**
   - Local **Tailwind CSS v3** compiled stylesheet (`output.css`) and locally bundled **Lucide Icons** (`lucide.min.js`).
   - Zero external CDN network dependencies — runs reliably even under strict firewalls or offline networks.

7. **📖 OpenAPI & Swagger Interactive API (`/docs`)**
   - Full FastAPI interactive documentation to inspect and test all REST API endpoints.

---

## 🏗️ Tech Stack

- **Backend**: FastAPI, Uvicorn, Starlette Session Middleware
- **Database & Auth**: Supabase (PostgreSQL, Row Level Security, Supabase Auth)
- **AI & NLP**: Google Gemini (`google-generativeai`, `google-genai`), Groq
- **Frontend**: Jinja2 Templates, Tailwind CSS (Compiled), Lucide Icons
- **Healthcare Standards**: HL7 FHIR R4 Specification, NAMASTE Standard Terminology

---

## 📁 Project Structure

```text
fastapi_app/
├── app/
│   ├── main.py                  # FastAPI application entry point & route registration
│   ├── config.py                # Environment configuration & settings
│   ├── dependencies.py          # Session auth guard & user injection
│   ├── supabase_client.py       # Supabase client instances (anon + service role)
│   ├── routers/
│   │   ├── auth.py              # User authentication (Login, Signup, Logout)
│   │   ├── patients.py          # EHR intake, patient history, FHIR bundle generation
│   │   ├── patient_dashboard.py # Doctor review dashboard & Gemini AI chat
│   │   ├── patient_portal.py    # Patient-facing portal view
│   │   ├── namaste.py           # NAMASTE AYUSH code search API & UI
│   │   └── diet.py              # Ayurvedic diet planning engine
│   ├── services/
│   │   ├── ai_doctor.py         # Google Gemini integration & clinical prompts
│   │   ├── fhir.py              # FHIR R4 JSON Bundle transformation
│   │   ├── intake.py            # Clinical note processing & triage
│   │   └── patients.py          # Patient data access layer
│   ├── static/
│   │   ├── css/                 # Compiled output.css & style.css
│   │   └── js/                  # Locally bundled lucide.min.js
│   └── templates/
│       ├── base.html            # Core layout with sidebar & topbar
│       ├── ehr.html             # EHR Progress notes entry
│       ├── patient_dashboard.html# AI doctor consultation dashboard
│       ├── history.html         # Patient records list
│       ├── namaste.html         # NAMASTE search interface
│       ├── diet.html            # Diet recommendations
│       ├── login.html           # Authentication login
│       ├── signup.html          # Registration
│       └── partials/            # Reusable sidebar and topbar components
├── supabase/
│   ├── complete_setup.sql       # Full database schema, RLS policies & seed data
│   └── database_setup_guide.md  # Step-by-step database setup instructions
├── tailwind.config.js           # Tailwind CSS content configuration
├── tailwindcss.exe              # Standalone Tailwind CLI compiler
├── pyproject.toml               # Python project configuration
├── uv.lock                      # uv dependency lockfile
├── requirements.txt             # Standard pip requirements
└── .env.example                 # Example environment variable file
```

---

## 🚀 Quick Start Guide

### 1. Prerequisites
- **Python 3.11+ (64-bit)**
- **`uv`** package manager (recommended) or **`pip`**
- A **Supabase** account (Free tier)
- A **Google Gemini API Key** ([Get one here](https://aistudio.google.com/app/apikey))

---

### 2. Configure Environment Variables (`.env`)

Create a `.env` file in the project root:

```ini
# Supabase Configuration
SUPABASE_URL=https://<your-project-id>.supabase.co
SUPABASE_ANON_KEY=<your-supabase-anon-key>
SUPABASE_SERVICE_KEY=<your-supabase-service-role-jwt-key>

# Session Secret (random 32+ character string)
SESSION_SECRET=super-secret-ayush-fhir-key-2026-xyz

# Set to false for local development, true for production HTTPS
SESSION_COOKIE_SECURE=false

# Google Gemini API Key
GEMINI_API_KEY=<your-gemini-api-key>
```

> **Important on Supabase Keys:**
> - `SUPABASE_ANON_KEY`: Found in Supabase Dashboard → Project Settings → API Keys (`anon` / `public`).
> - `SUPABASE_SERVICE_KEY`: Must be the **JWT format** service role key (`eyJhbGciOiJIUzI1Ni...`) under Project Settings → API Keys → `service_role`.

---

### 3. Setup Supabase Database

1. Open your **Supabase Dashboard** → **SQL Editor**.
2. Open the file `supabase/complete_setup.sql`.
3. Copy the entire script, paste it into the SQL Editor, and click **Run**.
   *(This creates all tables: `patients`, `encounters`, `prescriptions`, `patient_intakes`, `ayurveda_terms`, `foods`, `diseases`, and seeds initial standard terminology data).*
4. **Disable Email Confirmation for local testing**:
   - Go to **Authentication** (shield icon) → **Providers** → **Email**.
   - Toggle **OFF** `Confirm email`.
   - Click **Save**.

---

### 4. Install Dependencies

Using **`uv`** (fastest):
```bash
uv sync
```

Or using **`pip`**:
```bash
pip install -r requirements.txt
```

---

### 5. Run the Application

Using **`uv`**:
```bash
uv run uvicorn app.main:app --reload --port 8000
```

Or using standard Python:
```bash
python -m uvicorn app.main:app --reload --port 8000
```

---

## 🌐 Application URLs

Once running, navigate to:

| Route | Description |
| :--- | :--- |
| **`http://127.0.0.1:8000/login`** | User Login |
| **`http://127.0.0.1:8000/signup`** | User Registration |
| **`http://127.0.0.1:8000/history`** | Patient History & Roster |
| **`http://127.0.0.1:8000/ehr`** | Clinical Intake & FHIR R4 Bundle Generator |
| **`http://127.0.0.1:8000/patient-dashboard`** | Doctor Review & **Gemini AI Doctor Consultation** |
| **`http://127.0.0.1:8000/namaste`** | NAMASTE National Terminology Search |
| **`http://127.0.0.1:8000/diet`** | Prakriti Diet Engine |
| **`http://127.0.0.1:8000/docs`** | Interactive FastAPI Swagger Documentation |

---

## 🎨 Recompiling Tailwind CSS (Optional)

If you modify templates in `app/templates/`, you can recompile the CSS instantly with the bundled CLI:

```bash
.\tailwindcss.exe -i app/static/css/style.css -o app/static/css/output.css --minify
```

---

## 🩺 Test Credentials

For quick testing without creating a new user, a pre-registered test doctor account is available:
- **Email:** `doctor.ayurveda.test@gmail.com`
- **Password:** `SuperPassword123!`

---

## 📄 License
MIT License. Built for healthcare technology research and clinical innovation.
