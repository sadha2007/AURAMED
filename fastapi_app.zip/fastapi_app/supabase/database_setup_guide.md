# Database Setup & Import Guide

This guide explains how to set up the Supabase database for the mini project on your own account. Some tables require only the structural schema, while others include important pre-seeded or baseline data.

## Prerequisites

1. Create a free account on [Supabase](https://supabase.com/).
2. Create a new project and note down your project credentials.
3. Access the **SQL Editor** tab on the left sidebar of your new Supabase dashboard.

---

## Step-by-Step Import Order

To avoid foreign key dependency errors (e.g., child tables referencing parent tables), please run your imports in the following strict order:

### 1. Base Tables (Schema Only)

Run these scripts first in the SQL Editor to create the empty table structures, columns, constraints, and indexes.

- **`patients` table**: Create this table first since other tables reference it.
- **`prescription` table**: Create this second.
- **`encounters` table**: Create this third, as it depends on the `patients` table.

### 2. Data-Important Tables (Full Table Exports)

For tables where historical data or baseline records are required for the project to function properly, import your full exported table data (`.sql` dumps containing `INSERT` statements).

- Paste your exported full-table data scripts into the SQL Editor and execute them.

---

## How to Execute Scripts in Supabase

1. Open your Supabase Project Dashboard.
2. Navigate to **SQL Editor** -> **New query**.
3. Copy and paste the respective SQL script (`.sql` file content) into the editor.
4. Click **Run** in the bottom right corner.
5. Verify success by navigating to the **Table Editor** to check that your tables and/or rows have populated correctly.

## Troubleshooting

- **Foreign Key Violation / Relation Does Not Exist Error:** Ensure that you have created the referenced parent table (like `patients` or `auth.users`) before running scripts that point to them.
