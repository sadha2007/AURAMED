# FastAPI Project Setup Guide (`uv`)

This guide explains how to set up and run this FastAPI backend project on **Windows (64-bit Python)** using **`uv`**, a fast Python package installer and resolver.

## Prerequisites

- **Python (64-bit)** installed on your Windows machine. (Verify by running `python -c "import struct; print(struct.calcsize('P') * 8)"` in your terminal, which should output `64`).
- **pip** (usually bundled with Python).

---

## Step 1: Install `uv` using `pip`

Open your command prompt or PowerShell and install `uv` globally for your Python environment:

```bash
pip install uv
```

*Verification:* Run `uv --version` to confirm it installed correctly.

---

## Step 2: Configure the Environment Variables (`.env`)

1. Locate the example environment file provided in the repository (e.g., `.env.example` or similar).
2. Create a copy of it and name it `.env` in the root directory of the project:
   ```bash
   copy .env.example .env
   ```
3. Open the newly created `.env` file and fill in your actual environment variables (such as your new Supabase keys and database URL).

---

## Step 3: Install Dependencies Using `uv.lock`

This project uses a `uv.lock` file to guarantee reproducible builds and exact package versions. 

Navigate to the project root directory in your terminal and run:

```bash
uv sync
```

*What this does:* `uv` will automatically create a virtual environment (if one doesn't exist), read the `uv.lock` file, and install all required dependencies at their exact specified versions.

---

## Step 4: Run the FastAPI Application

Once the dependencies are synced and your `.env` file is configured, start the development server using `uv`:

```bash
uv run uvicorn main:app --reload
```

*(Note: Replace `main:app` with your actual entry point module and FastAPI instance if it differs, e.g., `app.main:app`).*

*Verification:* Open your browser and navigate to `http://127.0.0.1:8000/docs` to view the interactive Swagger documentation.